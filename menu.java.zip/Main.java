import java.util.Scanner;

public class MenuRestaurante {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double total = 0.0;

        
        String[] pratos = {
            "1. Pizza Margherita - R$ 29.90",
            "2. Hambúrguer - R$ 19.90",
            "3. Lasanha - R$ 24.90",
            "4. Salada - R$ 14.90",
            "5. Refrigerante - R$ 5.00"
        };

       
        double[] precos = {29.90, 19.90, 24.90, 14.90, 5.00};

        System.out.println("Bem-vindo ao Restaurante iFood!");
        System.out.println("Selecione os itens do menu digitando o número correspondente.");

        
        for (String prato : pratos) {
            System.out.println(prato);
        }

       
        while (true) {
            System.out.print("\nDigite o número do prato que você deseja ou 0 para finalizar o pedido: ");
            int escolha = scanner.nextInt();

            if (escolha == 0) {
                break;
            } else if (escolha > 0 && escolha <= pratos.length) {
                total += precos[escolha - 1];
                System.out.println("Você adicionou: " + pratos[escolha - 1]);
            } else {
                System.out.println("Opção inválida! Tente novamente.");
            }
        }

        System.out.printf("\nSeu pedido totalizou: R$ %.2f\n", total);
        if (total > 0) {
            System.out.println("Obrigado por fazer o pedido! Aproveite sua refeição!");
        } else {
            System.out.println("Nenhum item foi selecionado. Até a próxima!");
        }

        scanner.close();
    }
}
