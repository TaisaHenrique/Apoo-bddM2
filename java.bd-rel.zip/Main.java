import java.sql.*;
import java.util.ArrayList;
import java.util.List;


class DatabaseConnection {
    private Connection connection;

    public DatabaseConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/seu_banco"; // Altere para seu banco de dados
        String user = "usuario"; // Altere para seu usuário
        String password = "senha"; // Altere para sua senha
        connection = DriverManager.getConnection(url, user, password);
    }

    public Connection getConnection() {
        return connection;
    }

    public void close() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }
}


class Restaurante {
    private int idRestaurante;
    private String nome;
    private String endereco;
    private String telefone;

    public Restaurante(String nome, String endereco, String telefone) {
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
    }

    public void save(Connection conn) throws SQLException {
        String sql = "INSERT INTO Restaurante (nome, endereco, telefone) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, nome);
            pstmt.setString(2, endereco);
            pstmt.setString(3, telefone);
            pstmt.executeUpdate();

            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                idRestaurante = rs.getInt(1);
            }
        }
    }

    
    public int getIdRestaurante() {
        return idRestaurante;
    }
}


class Pedido {
    private int idPedido;
    private int idRestaurante;
    private int idCliente;
    private Timestamp dataPedido;
    private int statusEntrega;

    public Pedido(int idRestaurante, int idCliente, Timestamp dataPedido, int statusEntrega) {
        this.idRestaurante = idRestaurante;
        this.idCliente = idCliente;
        this.dataPedido = dataPedido;
        this.statusEntrega = statusEntrega;
    }

    public void save(Connection conn) throws SQLException {
        String sql = "INSERT INTO Pedido (id_restaurante, id_cliente, data_pedido, status_entrega) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, idRestaurante);
            pstmt.setInt(2, idCliente);
            pstmt.setTimestamp(3, dataPedido);
            pstmt.setInt(4, statusEntrega);
            pstmt.executeUpdate();

            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                idPedido = rs.getInt(1);
            }
        }
    }

    
    public int getIdPedido() {
        return idPedido;
    }
}


class PedidoProduto {
    private int idPedido;
    private int idProduto;
    private int quantidade;

    public PedidoProduto(int idPedido, int idProduto, int quantidade) {
        this.idPedido = idPedido;
        this.idProduto = idProduto;
        this.quantidade = quantidade;
    }

    public void save(Connection conn) throws SQLException {
        String sql = "INSERT INTO Pedido_Produto (id_pedido, id_produto, quantidade) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idPedido);
            pstmt.setInt(2, idProduto);
            pstmt.setInt(3, quantidade);
            pstmt.executeUpdate();
        }
    }
}


public class Main {
    public static void main(String[] args) {
        try {
            DatabaseConnection dbConnection = new DatabaseConnection();
            Connection conn = dbConnection.getConnection();


            Restaurante restaurante = new Restaurante("Restaurante Exemplo", "Rua Exemplo, 123", "1234-5678");
            restaurante.save(conn);

           
            Pedido pedido = new Pedido(restaurante.getIdRestaurante(), 1, new Timestamp(System.currentTimeMillis()), 1);
            pedido.save(conn);

            
            PedidoProduto pedidoProduto = new PedidoProduto(pedido.getIdPedido(), 1, 2);
            pedidoProduto.save(conn);

            
            dbConnection.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
